<?php

return [
    'name' => 'Auth'
];
