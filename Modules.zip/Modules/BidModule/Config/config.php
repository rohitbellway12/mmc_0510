<?php

return [
    'name' => 'BidModule'
];
